//
//  Automobiles.swift
//  JavierNieto_DetailedView
//
//  Created by X on 6/7/20.
//  Copyright © 2020 X. All rights reserved.
//

import Foundation
// did not use

class Automobiles {
    var name: String!
    var cost: String!
    var location: String!
    var website: String!
    var icon: String!
    var crest: String!
    var videoUrl: String!
    
    init(name: String, cost: String, location: String, website: String, icon: String, crest: String, videoUrl: String) {
        self.name = name
        self.cost = cost
        self.location = location
        self.website = website
        self.icon = icon
        self.crest = crest
        self.videoUrl = videoUrl
    }
}
