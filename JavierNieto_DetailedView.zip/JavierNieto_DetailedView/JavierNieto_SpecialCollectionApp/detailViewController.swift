//
//  detailViewController.swift
//  JavierNieto_DetailedViewApp
//
//  Created by X on 6/3/20.
//  Copyright © 2020 X. All rights reserved.
//

import UIKit

class detailViewController: UIViewController {
    @IBOutlet weak var lblCarName: UILabel!
    @IBOutlet weak var imgCarModel: UIImageView!
    @IBOutlet weak var lblTextField: UITextView!
    
    var receivingCar: String?
    var receivingImage : String?
    var transferURL: String!

    override func viewDidLoad() {
        super.viewDidLoad()
        lblCarName.text = receivingCar// Data from segue is assigned to label
        // Do any additional setup after loading the view.
        imgCarModel.image = UIImage(named: "\(receivingCar!.lowercased())-foto")
        //lblTextField.text = transferURL
        
        //custom Naivigation Bar
        navigationController?.navigationBar.tintColor = UIColor.red
        navigationController?.navigationBar.barTintColor = UIColor.yellow
        let customViewBar = UIBarButtonItem()
        customViewBar.title = "Back up to \(receivingCar!)" //(String(describing: receivingCar))"
        navigationItem.backBarButtonItem = customViewBar
        
       // receivingLinks
    }
    
    @IBAction func webVideoBtn(_ sender: Any) {
        performSegue(withIdentifier: "showWeb", sender: self)

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // let sectonSelected = carTable.indexPathForSelectedRow?.section
         //let rowSelected = carTable.indexPathForSelectedRow!.row
         
         if segue.identifier == "showWeb" {
             let destinWebVC = segue.destination as! webVC //casting
                // selectedItem = x.cars2Array[sectonSelected!][rowSelected + 1]
        destinWebVC.receivingLinks = transferURL // outside if stmt so data is given
        destinWebVC.receivingCar = receivingCar
         }
     }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
