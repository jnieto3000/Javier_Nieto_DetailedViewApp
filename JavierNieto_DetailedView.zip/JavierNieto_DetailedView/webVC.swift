//
//  webVC.swift
//  JavierNieto_DetailedView
//
//  Created by X on 6/6/20.
//  Copyright © 2020 X. All rights reserved.
//

import UIKit
import SwiftUI
import WebKit


class webVC: UIViewController , WKNavigationDelegate, WKUIDelegate {

    var webView: WKWebView!
    var receivingCar: String?
    var receivingLinks: String = "https://youtu.be/3cg8mhXPz2M"
    
    override func loadView() {
       webView = WKWebView()
       webView.navigationDelegate = self
        view = webView
        //webView = WKWebView(frame: .zero, configuration: webConfiguration)
        //webView.uiDelegate = self
        //view = webView
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
    //custom Naivigation Bar
         navigationController?.navigationBar.tintColor = UIColor.red
         navigationController?.navigationBar.barTintColor = UIColor.yellow
         let customViewBar = UIBarButtonItem()
         customViewBar.title = "Back to \(receivingCar!)" //(String(describing: receivingCar))"
         navigationItem.backBarButtonItem = customViewBar
    
    // setting up myURL links with WebView
        let myURL = URL(string: receivingLinks)!
        webView.allowsBackForwardNavigationGestures = true
        webView.allowsLinkPreview = true
        webView.load(URLRequest(url: myURL))
    }
}

/*
struct ContentView: View {
    var body: some View {
        Text("Hello world")
    }
}

#if DEBUG
struct ContentView_Previews :
    PreviewProvider {
        static var previews: some View{
            ContentView()
        }
}
#endif
*/
