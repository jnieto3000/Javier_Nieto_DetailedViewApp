//
//  ViewController.swift
//  JavierNieto_DetailView
//
//  Created by X on 5/31/20.
//  Copyright © 2020 X. All rights reserved.
//  M04 Assignment: Special Collection App
//  1) At least three groups with headers
//  2) Customized cells with images
//  3) An index sorting the data by topic or name
//  4)Design an app that allows you to select an object that launches a detailed view.
//  5) Be sure to pass some data from the first view to the detailed view.
//  6) Customize the detail view with navigation bar prompts, a custom back button, color scheme, and buttons to suit your needs.
//  7) Extra Launch a youTube video clip of of each

import UIKit
// 2 dimensional arrays of cars for names and logos. IndexArray id used is side a "stucture instead of usinf class Automobile
struct MyAutos{
    let cars2Array =  [["Extreme","Aston Martin","Bugatti","Lamborghini","Ferrari","Porsche"],
        ["Luxury","Bentley","Jaguar","Lexus","Mercedes","Rolls Royce"],
        ["Sport","Acura","Alfa Romeo","Audi","BMW","Tesla"],
        ["Regular","Buick","Cadillac","Chevrolet","Dodge","Ford","Honda","Mazda","Nissan","Toyota","Volkswagen"]]
    let indexArray = ["Extreme","Luxury","Sport","Regular"]
    let urlArray =  [ ["Extreme","https://youtu.be/YIUPOSAe7nc","https://youtu.be/7NZ9X9A2efA","https://youtu.be/fKNdoxRld34","https://youtu.be/3cg8mhXPz2M","https://youtu.be/ZUIHJ0ihUCQ","https://youtu.be/Krgg6rZ_isY"],   ["Luxury","https://www.hackingwithswift.com","https://youtu.be/fKNdoxRld34","https://www.lamborghini.com/en-en/models/huracan/huracan-evo"],
        ["Sport","Acura","Alfa Romeo","Audi","BMW","Tesla"],
        ["Regular","Buick","Cadillac","Chevrolet","Dodge","Ford","Honda","Mazda","Nissan","Toyota","Volkswagen"]]
    //"https://www.youtube.com/embed/sEydyLJ-wjw", "https://youtu.be/m5_AKjDdqaU","https://youtu.be/viW44cUfxCE",
    let image2Array = [["Extreme","aston martin-Logo","bugatti-Logo","lamborghini-Logo","ferrari-Logo","porsche-Logo"],
        ["Luxury","bentley-Logo","jaguar-logo","lexus-Logo","mercedes-Logo","rolls royce-Logo"],
        ["Sport","acura-Logo","alfa romeo-Logo","audi-Logo","bmw-Logo","Tesla-Logo"],
        ["Regular","buick-Logo","cadillac-Logo","chevrolet-Logo","dodge-Logo","ford-Logo","honda-LogoRed","mazda-Logo","nissan-Logo","toyota-Logo","volkswagen-Logo"]]
}

    let cellID = "cellID"       // for the carTable.dequeueReusableCell(withIdentifier: cellID
    var selectedItem: String = " " //Gobal variable to pass selected dar in segue to detailView
    var selectedItemImg: String = " " //Gobal will be used with receivingImage in segue
    var x = MyAutos()   //Going to make instance of Automibles but too much data to enter so used struct MyAutos{

//Main function
class ViewController: UIViewController {
    @IBOutlet weak var carTable: UITableView! // Car TableView outlet
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.

        carTable.dataSource = self
        carTable.delegate = self
        
        //custom Naivigation Bar
        navigationController?.navigationBar.tintColor = UIColor.red
        navigationController?.navigationBar.barTintColor = UIColor.yellow
        let customViewBar = UIBarButtonItem()
        customViewBar.title = "Back to Autos"
        navigationItem.backBarButtonItem = customViewBar
        
        //Index side bar
        carTable.sectionIndexColor = UIColor.yellow
        carTable.sectionIndexBackgroundColor = UIColor.red
        carTable.sectionIndexTrackingBackgroundColor = UIColor.darkGray
        }
}
// Extended ViewController
extension ViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = carTable.dequeueReusableCell(withIdentifier: cellID)
        
        if (cell == nil) {
    //same as below cell = UITableViewCell(style: UITableViewCell.CellStyle.default, reuseIdentifier: cellID)
            cell = UITableViewCell(style: .default, reuseIdentifier: cellID)
        }
      
        cell?.textLabel?.text = x.cars2Array[indexPath.section][indexPath.row + 1]
        cell?.imageView?.image = UIImage(named: x.image2Array[indexPath.section][indexPath.row + 1])
        return cell!
    }
    
    // Give the nuber of rows per category of cars
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return x.cars2Array[section].count-1
    }
    // Gives the count to creat sections
    func numberOfSections(in tableView: UITableView) -> Int {
        return x.cars2Array.count
    }
    
  // Takes the first  element of the 2D car array to give titles
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return x.cars2Array[section][0]
    }
 //This for creating the Sections or types of cars
    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return x.indexArray
    }
    
// Displays a pop up when you click on one of the items in the table view.
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        selectedItem = x.cars2Array[indexPath.section][indexPath.row + 1] //Gobal variable
        performSegue(withIdentifier: "showDetail", sender: self)
        tableView.deselectRow(at: indexPath, animated: true)
    /*
    let alert = UIAlertController(title: "Your Choice", message: "\(selectedItem)", preferredStyle:
    .alert)
    let okAction = UIAlertAction(title: "OK", style: .default, handler:{action->Void in}); alert.addAction(okAction)
    self.present(alert, animated: true, completion: nil)
    */
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let sectionSelected = carTable.indexPathForSelectedRow?.section
        let rowSelected = carTable.indexPathForSelectedRow!.row
        
        if segue.identifier == "showDetail" {
            let destinDetailVC = segue.destination as! detailViewController //casting
                selectedItem = x.cars2Array[sectionSelected!][rowSelected + 1]
            
            destinDetailVC.receivingCar = selectedItem   //cell.textLabel.text
            destinDetailVC.transferURL = x.urlArray[sectionSelected!][rowSelected + 1] // Sending URL  to receiving url in detail view
            //destinDetailVC.receivingImage = selectedItemImg
        }
    }
}
